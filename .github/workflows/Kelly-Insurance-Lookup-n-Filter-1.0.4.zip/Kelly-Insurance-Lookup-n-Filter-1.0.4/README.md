# Kelly-Insurance-Lookup-n-Filter
Electron Node JS program to scrape a .gov website (updated daily) for potential new clients meeting certain criteria, and generate both a .csv and .html report on those clients and their relevant information.
This code has no lisence. It is protected by personal copyright.
Copyright 2021 Jack Kelly